from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('comment/', views.add, name='comment'),
    path('entry/<str:id>/', views.entry, name='entry'),
]
