import os
import json
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.urls import reverse

ENTRIES_FILE = 'entries.json'

if not os.path.isfile(ENTRIES_FILE):
    with open(ENTRIES_FILE, 'w') as f:
        json.dump([], f)
with open(ENTRIES_FILE, 'r') as f:
    entries = json.load(f)
id_counter = len(entries) + 1

def entry(request, id):
    id = int(id) 
    for entry in entries:
        if entry['id'] == id:
            return JsonResponse(entry)
    return JsonResponse({'error': 'Entry not found for the id '+ str(id)})

def index(request):
    new_entry_id = request.GET.get('new_entry_id', None)
    context = {'entries': entries}
    if new_entry_id:
        context['new_entry_id'] = int(new_entry_id)
    return render(request, 'home.html', context)

def add(request):
    global id_counter
    if request.method == 'POST':
        content = request.POST['content']
        name = request.POST['name'].capitalize()
        if len(name) > 20:
            return render(request, 'comment.html', {'error': 'Name must not exceed 20 characters.'})
        if len(content) < 10 or len(content) > 120:
            return render(request, 'comment.html', {'error': 'Main content must be between 10 and 120 characters long.'})
        new_id = id_counter
        id_counter += 1
        entries.append({'id': new_id, 'content': content, 'name': name})
        new_entry = {'id': new_id, 'content': content, 'name': name}
        with open(ENTRIES_FILE, 'w') as f:
            json.dump(entries, f)
        return redirect(reverse('home') + f'?new_entry_id={new_id}')
    else:
        return render(request, 'comment.html')

